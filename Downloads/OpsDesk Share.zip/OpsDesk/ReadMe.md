# OpsDesk — An Obsidian workspace for IT operations

A daily workspace for tasks, meetings, projects, applications, and reusable knowledge.

## Quick start

1. Extract the entire ZIP into a folder you control. Keep the .obsidian folder and all subfolders together.
2. In Obsidian desktop, choose **Open folder as vault** and select the extracted **OpsDesk** folder.
3. Open **Settings → Community plugins**, turn on community plugins, and browse for **Dataview by Michael Brenan**. Install and enable it. The plugin itself is not bundled; its settings are supplied.
4. In **Settings → Dataview**, confirm **Enable JavaScript queries** is on. In **Core plugins**, confirm **Daily notes**, **Templates**, and **Bases** are enabled.
5. Run **Daily notes: Open today's daily note** from the command palette (Ctrl+P). After plugin setup, reopen the note if its buttons or queries have not refreshed.

Follow [[Vault Guide/Setup|Setup]] for all settings and checks, and [[Vault Guide/ReadMe|the workflow guide]] for everyday use.

## Included

- Daily template with task capture, carryover, and links to created entries.
- Meeting, Project, Note, general KB, and Application KB templates.
- Creation prompts, optional relationships, meeting dates, and project status controls.
- Editable Bases dashboards and folder-relative Attachments configuration.
- Shared support files under System and the complete Vault Guide.

Your Daily Notes folder starts empty; opening today's daily note creates the first entry. The source vault's dated daily note, workspace/tab state, and sync configuration are not included. No credentials or user-specific absolute paths are required.

Use this as a separate vault first. When merging into an existing vault, back it up and follow Setup rather than overwriting its .obsidian settings wholesale. Keep System collapsed during daily use.

The source workflow has been used in Obsidian. This package has been checked for file references and configuration consistency; a fresh-machine installation has not been tested.
